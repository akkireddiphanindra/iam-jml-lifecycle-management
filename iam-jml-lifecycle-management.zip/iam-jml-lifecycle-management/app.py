from datetime import datetime
import sqlite3
from pathlib import Path

from flask import Flask, flash, redirect, render_template, request, url_for

app = Flask(__name__)
app.secret_key = "change-this-for-local-development"
DB_PATH = Path(__file__).with_name("iam_jml.db")

DEPARTMENT_ACCESS = {
    "HR": ["HR Portal"],
    "Finance": ["Finance System"],
    "IT": ["IT Service Desk"],
    "Sales": ["CRM"],
    "Operations": ["Operations Portal"],
}


def connect_db():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def init_db():
    with connect_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS employees (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                department TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Active',
                access TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS audit_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id INTEGER,
                action TEXT NOT NULL,
                details TEXT NOT NULL,
                timestamp TEXT NOT NULL
            )
        """)


def log_action(db, employee_id, action, details):
    db.execute(
        "INSERT INTO audit_log (employee_id, action, details, timestamp) VALUES (?, ?, ?, ?)",
        (employee_id, action, details, datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    )


@app.route("/")
def index():
    with connect_db() as db:
        employees = db.execute("SELECT * FROM employees ORDER BY id DESC").fetchall()
        logs = db.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 10").fetchall()
    return render_template(
        "index.html",
        employees=employees,
        logs=logs,
        departments=DEPARTMENT_ACCESS.keys(),
        access_map=DEPARTMENT_ACCESS,
    )


@app.route("/joiner", methods=["POST"])
def joiner():
    name = request.form.get("name", "").strip()
    email = request.form.get("email", "").strip().lower()
    department = request.form.get("department", "")
    if not name or not email or department not in DEPARTMENT_ACCESS:
        flash("Enter a name, valid email, and department.", "error")
        return redirect(url_for("index"))

    access = ", ".join(DEPARTMENT_ACCESS[department])
    with connect_db() as db:
        try:
            cursor = db.execute(
                "INSERT INTO employees (name, email, department, status, access, created_at) VALUES (?, ?, ?, 'Active', ?, ?)",
                (name, email, department, access, datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
            )
            log_action(db, cursor.lastrowid, "JOINER", f"Created account record; assigned simulated access: {access}")
            flash(f"Employee added. Simulated access assigned: {access}", "success")
        except sqlite3.IntegrityError:
            flash("That email address already exists.", "error")
    return redirect(url_for("index"))


@app.route("/mover/<int:employee_id>", methods=["POST"])
def mover(employee_id):
    department = request.form.get("department", "")
    if department not in DEPARTMENT_ACCESS:
        flash("Select a valid department.", "error")
        return redirect(url_for("index"))

    with connect_db() as db:
        employee = db.execute("SELECT * FROM employees WHERE id = ?", (employee_id,)).fetchone()
        if not employee:
            flash("Employee not found.", "error")
        elif employee["status"] != "Active":
            flash("Only active employees can be moved.", "error")
        else:
            old_department = employee["department"]
            access = ", ".join(DEPARTMENT_ACCESS[department])
            db.execute(
                "UPDATE employees SET department = ?, access = ? WHERE id = ?",
                (department, access, employee_id),
            )
            log_action(
                db, employee_id, "MOVER",
                f"Department changed from {old_department} to {department}; simulated access updated to: {access}",
            )
            flash(f"Employee moved to {department}; simulated access updated.", "success")
    return redirect(url_for("index"))


@app.route("/leaver/<int:employee_id>", methods=["POST"])
def leaver(employee_id):
    with connect_db() as db:
        employee = db.execute("SELECT * FROM employees WHERE id = ?", (employee_id,)).fetchone()
        if not employee:
            flash("Employee not found.", "error")
        elif employee["status"] == "Inactive":
            flash("Employee is already inactive.", "error")
        else:
            db.execute(
                "UPDATE employees SET status = 'Inactive', access = 'Revoked (simulated)' WHERE id = ?",
                (employee_id,),
            )
            log_action(db, employee_id, "LEAVER", "Employee marked inactive; access revocation recorded (simulation only).")
            flash("Employee marked inactive. Access revocation was recorded in this demo.", "success")
    return redirect(url_for("index"))


@app.route("/audit")
def audit():
    with connect_db() as db:
        logs = db.execute("SELECT * FROM audit_log ORDER BY id DESC").fetchall()
    return render_template("audit.html", logs=logs)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
