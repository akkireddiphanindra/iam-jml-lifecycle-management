# IAM JML Lifecycle Management

A beginner-friendly **Identity and Access Management (IAM)** demo that illustrates the Joiner-Mover-Leaver (JML) lifecycle using Python, Flask, and SQLite.

## Features

- **Joiner:** Add an employee and assign simulated access based on department.
- **Mover:** Change an active employee's department and update the demo access mapping.
- **Leaver:** Mark an employee inactive and record simulated access revocation.
- **Audit log:** Record lifecycle actions with timestamps and details.
- **Employee directory:** View status, department, and simulated access.

## Technology

- Python
- Flask
- SQLite
- HTML/CSS
- IAM concepts: JML, role-based access assignment, least privilege, access lifecycle, audit trail

## Run locally

1. Install Python 3.10 or newer.
2. Download or clone this repository.
3. Open a terminal in the project directory.
4. Create and activate a virtual environment:

   **Windows**
   ```powershell
   python -m venv .venv
   .venv\Scripts\Activate.ps1
   ```

   **macOS/Linux**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   ```

5. Install dependencies and start the app:

   ```bash
   pip install -r requirements.txt
   python app.py
   ```

6. Open http://127.0.0.1:5000 in your browser.

## Try the workflow

1. Add a fictional employee, for example `Demo User` with `demo@example.com` in HR.
2. Change the employee's department using **Move**.
3. Use **Leaver** to mark the employee inactive.
4. Open the audit log to review the recorded events.

Use fictional employee details only.

## Important limitations

This is an educational local demo. It does **not** connect to Saviynt, Active Directory, Microsoft Entra ID, or any production system. Access assignment and revocation are simulated records, not real account changes. The app has not been designed or reviewed for production deployment. Do not expose it publicly or enter real personal data.

## Project status

Local demonstration prototype. Add your own screenshots and test results after running and verifying the application.
